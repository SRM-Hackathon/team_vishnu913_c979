import 'package:flutter/material.dart';
import 'lostform.dart';

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DefaultTabController(
        length: 2,
        child: new Scaffold(
          body: TabBarView(
            children: [
              new Scaffold(
                body: SafeArea(
                  child: Column( 
                    children: <Widget>[ 
                      
                      
                    ],
                  ),
                ),
                floatingActionButton: FloatingActionButton(
                  onPressed: (){},
                  child: Icon(Icons.add),
                ),
              ),
              new Scaffold(
                
                body: Column( 
                  children: <Widget>[ 
                    
                    
                  ],
                ),
                floatingActionButton: FloatingActionButton(
                  onPressed: () async{
                    await Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => LostFormPage()));
                  },
                  child: Icon(Icons.add),
                ),
              ),
              
            ],
          ),
          bottomNavigationBar: new TabBar(
            tabs: [
              Tab(
                icon: new Icon(Icons.location_searching),
                text: "Lost"
              ),
              Tab(
                icon: new Icon(Icons.child_care),
                text:"Found"
              ),
            ],
            labelColor: Colors.yellow,
            unselectedLabelColor: Colors.blue,
            indicatorSize: TabBarIndicatorSize.label,
            indicatorPadding: EdgeInsets.all(5.0),
            indicatorColor: Colors.red,
          ),
          backgroundColor: Colors.black,
        ),
      ),
    );
  }
}